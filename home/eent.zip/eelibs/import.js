import './js/dropdown.js';
import './js/fetch.js';
import './js/notification.js';
import './js/pages.js';
import './js/translator.js';
import './js/websocket.js';