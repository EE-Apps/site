class calculator {
    constructor(parameters) {
        
    }
}